export interface IUserFormData {
  email: string;
  password: string;
}